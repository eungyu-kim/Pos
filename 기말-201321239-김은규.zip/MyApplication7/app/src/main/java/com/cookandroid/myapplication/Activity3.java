package com.cookandroid.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by 김은규 on 2016-12-02.
 */
public class Activity3 extends Activity {
    //이전, 다음, 저장 버튼, 결제 버튼, 테이블 초기화
    Button btnNext, btnPrev, VPay, Tset;
    ViewFlipper viewFlipper;
    //테이블 번호
    EditText edtTable;
    //텍스트뷰 아이디 찾기
    TextView[] TextViewID = new TextView[13];
    Integer[] TextViewIDs = {R.id.tbn1, R.id.tbn2, R.id.tbn3, R.id.tbn4, R.id.tbn5, R.id.tbn6, R.id.tbn7,
            R.id.tbn8, R.id.tbn9, R.id.tbn10, R.id.tbn11, R.id.tbn12, R.id.tbn13};
    //파일 이름
    //텍스트뷰 아이디 찾기
    TextView[] TextViewIDV = new TextView[13];
    Integer[] TextViewIDsV = {R.id.tbnv1, R.id.tbnv2, R.id.tbnv3, R.id.tbnv4, R.id.tbnv5, R.id.tbnv6, R.id.tbnv7,
            R.id.tbnv8, R.id.tbnv9, R.id.tbnv10, R.id.tbnv11, R.id.tbnv12, R.id.tbnv13};
    String fileName, fileNum;
    int VResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3);
        Button btnReturn = (Button) findViewById(R.id.btnReturn);
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //텍스트 뷰 아이디 저장
        for (int i = 0; i < 13; i++) {
            TextViewID[i] = (TextView) findViewById(TextViewIDs[i]);
            TextViewIDV[i] = (TextView) findViewById(TextViewIDsV[i]);
        }

        //버튼 찾기
        btnNext = (Button) findViewById(R.id.btnNext);
        btnPrev = (Button) findViewById(R.id.btnPrev);
        viewFlipper = (ViewFlipper) findViewById(R.id.viewFlipper);
        VPay = (Button)findViewById(R.id.VPay);
        edtTable = (EditText)findViewById(R.id.edtTable);
        Tset = (Button)findViewById(R.id.Tset);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewFlipper.showNext();
            }
        });
        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewFlipper.showPrevious();
            }
        });

        //주문 상품 받기
        Intent intent1 = getIntent();
        String sum1 = intent1.getStringExtra("OderResult");
        final int edtbuffer1 = intent1.getIntExtra("Edtbuffer", 0);

        //파일 이름
        fileName = "file" + Integer.toString(edtbuffer1) + ".txt";
        //텍스트 저장
        for (int i = 0; i < 13; i++) {
            if (edtbuffer1 == (i + 1)) {
                String strbuffer = readData("file" + i + ".txt",500);
                String result = strbuffer + '\n' + sum1;
                try {
                    FileOutputStream outFs = openFileOutput("file" + i + ".txt", Context.MODE_WORLD_WRITEABLE);
                    outFs.write(result.getBytes());
                    outFs.close();
                } catch (IOException e) {
                }
            }
        }

        //결제 값 받고 저장
        final int PaySum = intent1.getIntExtra("VResult", 0);
        for (int i = 0; i < 13; i++) {
            if (edtbuffer1 == (i + 1)) {
                String strbuffer = readData("fileV" + i + ".txt", 50);
                int change = Integer.parseInt(strbuffer);
                int Change = PaySum + change;
                String result = String.valueOf(Change);
                try {
                    FileOutputStream outFs = openFileOutput("fileV" + i + ".txt", Context.MODE_WORLD_WRITEABLE);
                    outFs.write(result.getBytes());
                    outFs.close();
                } catch (IOException e) {}
            }
        }
        //저장 파일 출력
        for (int i = 0; i < 13; i++) {
            String print1 = readData("file" + i + ".txt", 500);
            String print2 = readData("fileV" + i + ".txt", 50);
            TextViewID[i].setText(print1);
            TextViewIDV[i].setText(print2);
        }

        //결제 가격 넘기기
        VPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //결제 에디트 텍스트에서 값 가져오기
                String Vbuffer = edtTable.getText().toString();
                //인트형으로 형변환
                int Vnum = Integer.parseInt(Vbuffer);
                String num = TextViewIDV[(Vnum-1)].getText().toString();
                VResult = Integer.parseInt(num);
                //결과 값 보내기
                Intent intent = new Intent(getApplicationContext(),Activity4.class);
                intent.putExtra("PayResult",VResult);
                startActivity(intent);
            }
        });

        Tset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtTable.isFocused() == true) {
                    String buffer = edtTable.getText().toString();
                    //테이블 번호를 입력하지 않았을떄
                    if (buffer.equals("")) {
                        Toast.makeText(getApplicationContext(),"테이블 번호를 입력하세요",Toast.LENGTH_SHORT).show();
                    }
                    else  {
                        //인트형으로 변환;
                        int Ibuffer = Integer.parseInt(buffer);
                        if((Ibuffer >=1) && (Ibuffer <=13)) {
                            try {
                                //테이블 파일 초기화
                                FileOutputStream outFs = openFileOutput("file" + (Ibuffer-1) + ".txt", Context.MODE_WORLD_WRITEABLE);
                                fileNum = (Ibuffer) + "번";
                                outFs.write(fileNum.getBytes());
                                outFs.close();
                            } catch (IOException e) {}
                            try {
                                //테이블 당 급액 초기화
                                FileOutputStream outFsV = openFileOutput("fileV" + (Ibuffer-1) + ".txt", Context.MODE_WORLD_WRITEABLE);
                                fileNum = "0";
                                outFsV.write(fileNum.getBytes());
                                outFsV.close();
                            } catch (IOException e) {}
                            TextViewID[(Ibuffer-1)].setText(Ibuffer+"번");
                            TextViewIDV[(Ibuffer-1)].setText("0");
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"테이블 번호(1~13)를 정확히입력하세요",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(),"테이블텍스트에 번호를 써주세요",Toast.LENGTH_SHORT).show();
                }
            }
        });

        //메뉴 달기
        registerForContextMenu(Tset);
    }
    String readData(String fileName,int v) {
        String OderStr = null;
        FileInputStream infs;
        try {
            infs = openFileInput(fileName);
            byte[] txt = new byte[v];
            infs.read(txt);
            infs.close();;
            OderStr = (new String(txt)).trim();
        }catch (IOException e) {
        }
        return OderStr;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater mInfater = getMenuInflater();
        if( v == Tset) {
            menu.setHeaderTitle("테이블 전체 초기화");
            mInfater.inflate(R.menu.menu1, menu);
        }
    }

    //전체 테이블 초기화
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.itemReSet)
        {
            ReSet();
        }
        return super.onContextItemSelected(item);
    }

    public void ReSet() {
        for (int i = 0; i < 13; i++) {
            try {
                //테이블 파일 초기화
                FileOutputStream outFs = openFileOutput("file" + i + ".txt", Context.MODE_WORLD_WRITEABLE);
                fileNum = (i + 1) + "번";
                outFs.write(fileNum.getBytes());
                outFs.close();
            } catch (IOException e) {
            }
            try {
                //테이블 당 급액 초기화
                FileOutputStream outFsV = openFileOutput("fileV" + i + ".txt", Context.MODE_WORLD_WRITEABLE);
                fileNum = "0";
                outFsV.write(fileNum.getBytes());
                outFsV.close();
            } catch (IOException e) {
            }
            try {
                //테이블 파일 읽어서 테이블 초기화
                FileInputStream inFs = openFileInput("file" + i + ".txt");
                byte[] txt = new byte[500];
                inFs.read(txt);
                String str = new String(txt);
                inFs.close();
                TextViewID[i].setText(str);
            } catch (IOException e) {
            }
            try {
                //금액 파일 읽어서 테이블 초기화
                FileInputStream inFsV = openFileInput("fileV" + i + ".txt");
                byte[] txt = new byte[50];
                inFsV.read(txt);
                String str = new String(txt);
                inFsV.close();
                TextViewIDV[i].setText(str);
            } catch (IOException e) {}
        }
    }
}
