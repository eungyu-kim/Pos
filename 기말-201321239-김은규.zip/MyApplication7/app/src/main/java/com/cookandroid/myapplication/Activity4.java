package com.cookandroid.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

/**
 * Created by 김은규 on 2016-12-05.
 */
public class Activity4 extends Activity {
    Button btnReturn4, BtnWrite;
    DatePicker dp;
    EditText PayEdt;
    public String fileName;
    TextView PayText;
    int PaySum, PayReSult =0;
    String GetPay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity4);

        //버튼 리턴
       btnReturn4 = (Button)findViewById(R.id.btnReturn4);
        btnReturn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        dp = (DatePicker)findViewById(R.id.datePicker1);
        PayEdt = (EditText)findViewById(R.id.PayEdt);
        BtnWrite = (Button)findViewById(R.id.btnWrite);
        PayText = (TextView)findViewById(R.id.PayText);

        Calendar cal = Calendar.getInstance();
        int cYear = cal.get(Calendar.YEAR);
        int cMonth = cal.get(Calendar.MONTH);
        int cDay = cal.get(Calendar.DAY_OF_MONTH);

        //결제값 받기
        Intent intent1 = getIntent();
        final int PaySum = intent1.getIntExtra("PayResult",0);
        PayText.setText(""+PaySum);


        dp.init(cYear, cMonth, cDay, new DatePicker.OnDateChangedListener() {
            public void onDateChanged(DatePicker view, int year,
                                      int monthOfYear, int dayOfMonth) {
                fileName = Integer.toString(year) + "_" + Integer.toString(monthOfYear +1) + "_"
                        +Integer.toString(dayOfMonth) + ".txt";
                String str = readPayMent(fileName);

                PayEdt.setText(str);
                BtnWrite.setEnabled(true);
            }
        });


        BtnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    FileOutputStream ouFs = openFileOutput(fileName, Context.MODE_WORLD_WRITEABLE);
                    String str = PayEdt.getText().toString();
                    if (str.equals("")) {
                        str = PayText.getText().toString();
                        ouFs.write(str.getBytes());
                        ouFs.close();
                    }
                    else {
                        GetPay = PayText.getText().toString();
                        PayReSult = Integer.parseInt(str) + Integer.parseInt(GetPay);
                        str = String.valueOf(PayReSult);
                        ouFs.write(str.getBytes());
                        ouFs.close();
                    }
                    Toast.makeText(getApplicationContext(), fileName+"결제내역 저장됨",Toast.LENGTH_SHORT).show();
                }catch (IOException e) {}
            }
        });

        //결제 초기화
        registerForContextMenu(BtnWrite);
    }
    String readPayMent(String fName) {
        String payStr = null;
        FileInputStream inFs;
        try {
            inFs = openFileInput(fName);
            byte[] txt = new byte[100];
            inFs.read(txt);
            inFs.close();
            payStr = (new String(txt)).trim();
            BtnWrite.setText("결제저장");
        }catch (IOException e) {}
        return payStr;
    }

    //컨텍스트 메뉴
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater mInflater = getMenuInflater();
        menu.setHeaderTitle("일일 총 매출 초기화");
        mInflater.inflate(R.menu.menu2, menu);
    }

    //컨텍스트 메뉴 선택시
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.itemPayReSet) {
            PayReSet();
        }
        return super.onContextItemSelected(item);
    }

    //일일 매출 초기화 함수
    public void PayReSet() {
        try {
            FileOutputStream ouFs = openFileOutput(fileName, Context.MODE_WORLD_WRITEABLE);
            String str = "";
            ouFs.write(str.getBytes());
            ouFs.close();
            PayEdt.setText(str);
            Toast.makeText(getApplicationContext(), fileName+"결제내역 초기화됨",Toast.LENGTH_SHORT).show();
        }catch (IOException e) {}
    }
}
