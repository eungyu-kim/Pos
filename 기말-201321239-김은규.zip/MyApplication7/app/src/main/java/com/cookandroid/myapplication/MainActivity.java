package com.cookandroid.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.test.ActivityInstrumentationTestCase2;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //다음,이전,더하기,빼기,곱하기,나누기,초기화, 메뉴화면, 주문화면, 주문버튼, 결제화면, 결제버튼
    Button btnNext, btnPrev, add, sub, mul,div,clear, Menu, Oder, oder, PayMent, Pay;
    ViewFlipper vFlipper;
    TextView text1, txtS, result;
    //주문상품버퍼, 저장버퍼, 문자숫자받기
    String num1, num2, getNum;
    EditText muledt;
    //상품 가격 ,결과 저장, 문자숫자 변환
    int buffer, sum, edtbuffer = 0;
    //에디트 택스트값 저장
    int changebuffer = 0;
    String Stringbuffer = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("풍류");

        Button button1;
        //문자열 초기화
        num1 = "";


        //버튼 아이디 찾기
        final Button[] numButtons = new Button[174];
        Integer[] numButtonIDs = { R.id.btn1, R.id.btn2,R.id.btn3,R.id.btn4,R.id.btn5, R.id.btn6, R.id.btn7,
                R.id.btn8, R.id.btn9, R.id.btn10, R.id.btn11, R.id.btn12, R.id.btn13, R.id.btn14, R.id.btn15,
                R.id.btn16, R.id.btn17, R.id.btn18, R.id.btn19, R.id.btn20, R.id.btn21, R.id.btn22, R.id.btn23,
                R.id.btn24, R.id.btn25, R.id.btn26, R.id.btn27, R.id.btn28, R.id.btn29, R.id.btn30, R.id.btn31,
                R.id.btn32, R.id.btn33, R.id.btn34, R.id.btn35, R.id.btn36, R.id.btn37, R.id.btn38, R.id.btn39,
                R.id.btn40, R.id.btn41, R.id.btn42, R.id.btn43, R.id.btn44, R.id.btn45, R.id.btn46, R.id.btn47,
                R.id.btn48, R.id.btn49, R.id.btn50, R.id.btn51, R.id.btn52, R.id.btn53, R.id.btn54, R.id.btn55,
                R.id.btn56, R.id.btn57, R.id.btn58, R.id.btn59, R.id.btn60, R.id.btn61, R.id.btn62, R.id.btn63,
                R.id.btn64, R.id.btn65, R.id.btn66, R.id.btn67, R.id.btn68, R.id.btn69, R.id.btn70, R.id.btn71,
                R.id.btn72, R.id.btn73, R.id.btn74, R.id.btn75, R.id.btn76, R.id.btn77, R.id.btn78, R.id.btn79,
                R.id.btn80, R.id.btn81, R.id.btn82, R.id.btn83, R.id.btn84, R.id.btn85, R.id.btn86, R.id.btn87,
                R.id.btn88, R.id.btn89, R.id.btn90, R.id.btn91, R.id.btn92, R.id.btn93, R.id.btn94, R.id.btn95,
                R.id.btn96, R.id.btn97, R.id.btn98, R.id.btn99, R.id.btn100, R.id.btn101, R.id.btn102, R.id.btn103,
                R.id.btn104, R.id.btn105, R.id.btn106, R.id.btn107, R.id.btn108, R.id.btn109, R.id.btn110, R.id.btn111,
                R.id.btn112, R.id.btn113, R.id.btn114, R.id.btn115, R.id.btn116, R.id.btn117, R.id.btn118, R.id.btn119,
                R.id.btn120, R.id.btn121, R.id.btn122, R.id.btn123, R.id.btn124, R.id.btn125, R.id.btn126, R.id.btn127,
                R.id.btn128, R.id.btn129, R.id.btn130, R.id.btn131, R.id.btn132, R.id.btn133, R.id.btn134, R.id.btn135,
                R.id.btn136, R.id.btn137, R.id.btn138, R.id.btn139, R.id.btn140, R.id.btn141, R.id.btn142, R.id.btn143,
                R.id.btn144, R.id.btn145, R.id.btn146, R.id.btn147, R.id.btn148, R.id.btn149, R.id.btn150, R.id.btn151,
                R.id.btn152, R.id.btn153, R.id.btn154, R.id.btn155, R.id.btn156, R.id.btn157, R.id.btn158, R.id.btn159,
                R.id.btn160, R.id.btn161, R.id.btn162, R.id.btn163, R.id.btn164, R.id.btn165, R.id.btn166, R.id.btn167,
                R.id.btn168, R.id.btn169, R.id.btn170, R.id.btn171, R.id.btn172, R.id.btn173, R.id.btn174};
        //상품 가격
        final Integer[] Price = {15000, 15000, 15000, 15000, 15000, 15000, 17000, 16000, 15000, 16000, 16000, 14000, 14000, 14000,
        13000, 15000, 1000, 15000, 2000, 3000, 13000, 13000, 12000, 13000, 13000, 12000, 7000, 13000, 7000, 13000, 7000, 12000, 13000,
        10000, 12000, 10000, 15000, 10000, 9000, 16000, 15000, 16000, 16000, 18000, 15000, 17000, 17000, 16000, 12000, 13000, 13000, 13000,
        15000, 500, 12000, 12000, 12000, 12000, 12000, 14000, 14000, 14000, 14000, 14000, 14000, 14000, 14000, 9000, 15000, 15000, 14000,
        15000, 14000, 15000, 18000, 15000, 8000, 13000, 8000, 9000, 7000, 7000, 6000, 4500, 4000, 4000, 4000, 5000, 8000, 8000, 8000, 8000,
        10000, 6000, 8000, 5000, 7000, 5000, 9000, 8000, 26000, 26000, 26000, 41000, 25000, 20000, 6000, 9000, 5000, 6000, 9000, 6000, 9000,
        5000, 8000, 1000, 5000, 7000, 5000, 8000, 5000, 8000, 8000, 8000, 8000, 8000, 8000, 4000, 4500, 4000, 3000, 9000, 12000, 3500, 12000,
        1400, 2000, 3500, 3500, 3500, 3500, 3500, 3500, 4000, 4500, 4000, 4000, 4500, 4500, 4500, 4500, 5000, 4500, 9000, 9000, 9000, 9000, 4500,
                4500, 4500, 4500, 4500, 6500, 9000, 4500, 9000, 4500, 9000, 4500, 12000, 12000, 12000, 12000, 12000,};
        int i;

        btnNext = (Button)findViewById(R.id.btnNext);
        btnPrev = (Button)findViewById(R.id.btnPrev);
        vFlipper = (ViewFlipper)findViewById(R.id.viewFlipper1);
        txtS = (TextView)findViewById(R.id.txtS);
        text1 = (TextView)findViewById(R.id.text1);
        add = (Button)findViewById(R.id.add);
        sub = (Button)findViewById(R.id.sub);
        mul = (Button)findViewById(R.id.mul);
        muledt = (EditText)findViewById(R.id.muledt);
        result = (TextView)findViewById(R.id.result);
        div = (Button)findViewById(R.id.div);
        clear = (Button)findViewById(R.id.clear);
        Menu = (Button)findViewById(R.id.Menu);
        Oder = (Button)findViewById(R.id.Oder);
        oder = (Button)findViewById(R.id.oder);
        PayMent = (Button)findViewById(R.id.PayMent);
        Pay = (Button)findViewById(R.id.Pay);


        //버튼 아이디 찾기
        for(i=0;i<174;i++) {
            numButtons[i] = (Button)findViewById(numButtonIDs[i]);
        }
        //버튼마다 가격 값 저장
        for(i=0;i<174;i++) {
            final int index;
            index =i;
            numButtons[index].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    num2 = numButtons[index].getText().toString();
                    buffer = Price[index];
                    txtS.setText(num2);
                }
            });
        }
         add.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 num1 += txtS.getText().toString()+'\n';
                 text1.setTextColor(Color.WHITE);
                 text1.setText(num1);
                 sum += buffer;
                 result.setText(""+sum);
             }
         });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1 += "-"+txtS.getText().toString()+'\n';
                text1.setTextColor(Color.RED);
                text1.setText(num1);
                sum -= buffer;
                result.setText(""+sum);
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(muledt.isFocused() == true) {
                    Stringbuffer = muledt.getText().toString();
                    //추가 개수를 입력하지 않았을떄
                    if (Stringbuffer.equals("")) {
                        Toast.makeText(getApplicationContext(),"추가 개수를 입력하세요",Toast.LENGTH_SHORT).show();
                    }
                    else  {
                        getNum = muledt.getText().toString();
                        num1 += txtS.getText().toString()+" "+getNum+"개"+'\n';
                        edtbuffer = Integer.parseInt(getNum);
                        text1.setTextColor(Color.GREEN);
                        text1.setText(num1);
                        sum += (buffer*edtbuffer);
                        result.setText(""+sum);
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(),"텍스트에 번호를 써주세요",Toast.LENGTH_SHORT).show();
                }
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(muledt.isFocused() == true) {
                    Stringbuffer = muledt.getText().toString();
                    //추가 개수를 입력하지 않았을떄
                    if (Stringbuffer.equals("")) {
                        Toast.makeText(getApplicationContext(),"추가 개수를 입력하세요",Toast.LENGTH_SHORT).show();
                    }
                    else  {
                        getNum = muledt.getText().toString();
                        num1 += "-"+txtS.getText().toString()+" "+muledt.getText().toString()+"개"+'\n';
                        text1.setTextColor(Color.BLUE);
                        text1.setText(num1);
                        sum -= (buffer*edtbuffer);
                        result.setText(""+sum);
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(),"텍스트에 번호를 써주세요",Toast.LENGTH_SHORT).show();
                }
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sum = 0;
                num1 = "";
                text1.setTextColor(Color.BLACK);
                text1.setText(num1);
                result.setText("");
            }
        });

        //뷰플립퍼 동작
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vFlipper.showNext();
            }
        });
        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vFlipper.showPrevious();
            }
        });

        //화면 넘기기
        Menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Activity1.class);
                startActivity(intent);
            }
        });
        Oder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Activity3.class);
                startActivity(intent);
            }
        });
        PayMent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Activity4.class);
                startActivity(intent);
            }
        });

        //주문 넘기기
        oder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(muledt.isFocused() == true) {
                    Stringbuffer = muledt.getText().toString();
                    //테이블 번호를 입력하지 않았을떄
                    if (Stringbuffer.equals("")) {
                        Toast.makeText(getApplicationContext(),"테이블 번호를 입력하세요",Toast.LENGTH_SHORT).show();
                    }
                    else  {
                        //인트형으로 변환;
                        changebuffer = Integer.parseInt(Stringbuffer);
                        if((changebuffer >=1) && (changebuffer <=13)) {
                            Intent intent1 = new Intent(getApplicationContext(), Activity3.class);
                            intent1.putExtra("OderResult", num1);
                            intent1.putExtra("Edtbuffer", changebuffer);
                            intent1.putExtra("VResult", sum);
                            startActivity(intent1);
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"테이블 번호(1~13)를 정확히입력하세요",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(),"테이블텍스트에 번호를 써주세요",Toast.LENGTH_SHORT).show();
                }
            }
        });

        //가격 넘기기
        Pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Activity4.class);
                intent.putExtra("PayResult",sum);
                startActivity(intent);
            }
        });
    }
}
