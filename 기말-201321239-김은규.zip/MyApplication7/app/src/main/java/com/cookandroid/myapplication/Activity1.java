package com.cookandroid.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ViewFlipper;

/**
 * Created by 김은규 on 2016-12-02.
 */
public class Activity1 extends Activity {

    ViewFlipper viewFlipper2;
    Button btnNext2, btnPrev2, btnReturn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);

        btnReturn2 = (Button)findViewById(R.id.btnReturn2);
        btnNext2 = (Button)findViewById(R.id.btnNext2);
        btnPrev2 = (Button)findViewById(R.id.btnPrev2);
        viewFlipper2 = (ViewFlipper)findViewById(R.id.viewFlipper2);

        btnReturn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewFlipper2.showNext();
                Toast.makeText(getApplicationContext(), "다음 화면으로 이동했습니다.",Toast.LENGTH_SHORT).show();
            }
        });
        btnPrev2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewFlipper2.showPrevious();
                Toast.makeText(getApplicationContext(), "이전 화면으로 이동했습니다.",Toast.LENGTH_SHORT).show();
            }
        });
    }
}
